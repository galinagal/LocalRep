class User < ActiveRecord::Base
  has_secure_password

  has_many :petitions

  validates :email, presence: true
  validates :password, presence: true
  validates :first_name, presence: true, length: { minimum: 2 }
  validates :last_name, presence: true, length: { minimum: 2 }
  
  def name
    "#{first_name} #{last_name}"
  end
end
